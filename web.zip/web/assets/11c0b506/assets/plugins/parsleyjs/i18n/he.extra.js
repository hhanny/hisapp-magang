// Validation errors messages for Parsley
// Load this after Parsley

Parsley.addMessages('he', {
  dateiso: "ערך זה צריך להיות תאריך בפורמט (YYYY-MM-DD)."
});
